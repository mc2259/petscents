//
//  ViewController.swift
//  LectureTwoAgain
//
//  Created by Yana Sang on 9/30/19.
//  Copyright © 2019 Yana Sang. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var imageView: UIImageView!
    var nameLabel: UILabel!
    var followButton: UIButton!
    var bioTextView: UITextView!
    
    var isFollowing: Bool = false
    
    let imageViewLength: CGFloat = 150

    override func viewDidLoad() {
        super.viewDidLoad()

        view.backgroundColor = .white
        
        imageView = UIImageView()
        imageView.image = UIImage(named: "image1")
        imageView.clipsToBounds = true
        imageView.layer.cornerRadius = imageViewLength / 2
        imageView.contentMode = .scaleAspectFit
        imageView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(imageView)
        
        nameLabel = UILabel()
        nameLabel.text = "Rakshit"
        nameLabel.textColor = .black
        nameLabel.textAlignment = .center
        nameLabel.font = UIFont.systemFont(ofSize: 16, weight: .bold)
        nameLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(nameLabel)
        
        followButton = UIButton()
        followButton.backgroundColor = .white
        followButton.addTarget(self, action: #selector(followButtonPressed), for: .touchUpInside)
        followButton.setTitle("Follow", for: .normal)
        followButton.setTitleColor(.systemBlue, for: .normal)
        followButton.layer.borderColor = UIColor.systemBlue.cgColor
        followButton.layer.borderWidth = 1
        followButton.translatesAutoresizingMaskIntoConstraints = false
        followButton.contentEdgeInsets = UIEdgeInsets(top: 5, left: 10, bottom: 5, right: 10)
        view.addSubview(followButton)
        
        bioTextView = UITextView()
        bioTextView.text = "Hi Rakshit"
        bioTextView.textColor = .black
        
        bioTextView.isEditable = true
        bioTextView.layer.borderColor = UIColor.systemGray.cgColor
        bioTextView.layer.borderWidth = 1
        bioTextView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(bioTextView)
        
        setupConstraints()
    }
    
    @objc func followButtonPressed() {
        followButton.setTitle(isFollowing ? "Follow" : "Following", for: .normal)
        followButton.setTitleColor(isFollowing ? .white : .systemBlue, for: .normal)
        followButton.backgroundColor = isFollowing ? .systemBlue : .white
        isFollowing.toggle()
    }
    
    func setupConstraints() {
        NSLayoutConstraint.activate([
            imageView.widthAnchor.constraint(equalToConstant: imageViewLength),
            imageView.heightAnchor.constraint(equalToConstant: imageViewLength),
            imageView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            imageView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
        ])
        
        NSLayoutConstraint.activate([
            nameLabel.topAnchor.constraint(equalTo: imageView.bottomAnchor, constant: 15),
            nameLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
        ])
        
        NSLayoutConstraint.activate([
            followButton.topAnchor.constraint(equalTo: nameLabel.bottomAnchor, constant: 10),
            followButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
        ])
        
        NSLayoutConstraint.activate([
            bioTextView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 15),
            bioTextView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -15),
            bioTextView.topAnchor.constraint(equalTo: followButton.bottomAnchor, constant: 15),
            bioTextView.bottomAnchor.constraint(equalTo: bioTextView.topAnchor,constant: 150),
        ])
    }

}
