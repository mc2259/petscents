//
//  ViewController2.swift
//  L5
//
//  Created by Maitreyi Chatterjee on 25/01/20.
//  Copyright © 2020 Kevin Chan. All rights reserved.
//

import UIKit

class ViewController2: UIViewController {
    
    let padding: CGFloat = 10
 
    
    
    //vet Hospital,Vet Contact Info,Upload photo,Pic of Pet,Story of Doggy
    
    
    
    
    
    var getdonation: UIButton!
    var isselected:Bool = false
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        getdonation=UIButton()
        
        getdonation.backgroundColor = .white
        getdonation.addTarget(self, action: #selector(followButtonPressed), for: .touchUpInside)
        getdonation.setTitle("Get Donation", for: .normal)
        getdonation.setTitleColor(.red, for: .normal)
        getdonation.layer.borderColor = UIColor.red.cgColor
        getdonation.layer.borderWidth = 1
        getdonation.translatesAutoresizingMaskIntoConstraints = false
        getdonation.contentEdgeInsets = UIEdgeInsets(top: 5, left: 10, bottom: 5, right: 10)
                     view.addSubview(getdonation)
        getdonation.layer.cornerRadius=10
        setupconstraints()
    }
    func setupconstraints()
    {
        NSLayoutConstraint.activate([
                  getdonation.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: padding),
                  getdonation.leadingAnchor.constraint(equalTo: view.leadingAnchor,constant:padding),
                  getdonation.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor,constant:75),
                  getdonation.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -padding)
              ])
    }
        
        
        @objc func followButtonPressed() {
        
              getdonation.setTitleColor(isselected ? .red : .white, for: .normal)
              getdonation.backgroundColor = isselected ? .white : .red
            isselected.toggle()
            var  vc = ViewController()
            
                
                navigationController?.pushViewController(vc, animated: true)
                
                
              
          
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
