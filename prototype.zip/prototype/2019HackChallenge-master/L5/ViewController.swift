
//
//  ViewController.swift
//  L5
//
//  Created by Maitreyi Chatterjee on 11/05/19.
//  Copyright © 2019 Maitreyi Chatterjee. All rights reserved.
//
import UIKit


class ViewController: UIViewController, UISearchResultsUpdating {
    
    
    func updateSearchResults(for searchController: UISearchController) {
        
    }
     
      
   
    
   
    
    var filterView:UICollectionView!
    var collectionView: UICollectionView!
    
    var persons: [Restaurant] = []
    var restaurants: [Restaurant] = []
 
    var isselected:Bool = false
    var givedonation: UIButton!
    //var getdonation:UIButton!

    
    
    
    var filters: [Filter] = []
    
    var selectedFilters: [String] = []
    var restaurant1: Restaurant!
    var restaurant2: Restaurant!
    var restaurant3: Restaurant!
    var restaurant4: Restaurant!
    var restaurant5: Restaurant!
    var restaurant6: Restaurant!
    var restaurant7: Restaurant!
    var restaurant8: Restaurant!
    var restaurant9: Restaurant!
    var restaurant10: Restaurant!
    var restaurant11: Restaurant!
    var nearestFirst: Filter!
    var north: Filter!
    var central: Filter!
    var west: Filter!
    var BRB: Filter!
    var filter6: Filter!
    var filter7: Filter!
    var filter8: Filter!
    var filter9: Filter!
    var filter10: Filter!
     
    let personCellReuseIdentifier = "personCellReuseIdentifier"
    let filterCellReuseIdentifier = "filterCellReuseIdentifier"
    

    let padding: CGFloat = 10
    
  

    override func viewDidLoad() {
        super.viewDidLoad()
        
       
        
        
        title = "PETCENTS"
        view.backgroundColor = .white
        
        // Create Person objects
        
        restaurant1 = Restaurant(food: "dog", imageName: "saddog", name: "Jimmy| Needs $5000| NY")
      
        restaurant3 = Restaurant(food: "dog", imageName: "saddog1", name: "Dexter| Needs $10000 | CA")
        restaurant4 = Restaurant(food: "cat", imageName: "saddog2", name: "Read How Rob Found a Home")
        
        restaurant5 = Restaurant(food: "cattle", imageName: "cattle", name: "Katherine")
        restaurant6 = Restaurant(food: "dog", imageName: "dog3", name: "Jimmy")
        
        restaurant7 = Restaurant(food: "fish", imageName: "fish", name: "Bushy")
        restaurant8 = Restaurant(food: "cattle", imageName: "cattle", name: "Chinky")
        
        restaurant9 = Restaurant(food: "dog", imageName: "dog2", name: "Pinky")
        restaurant10 = Restaurant(food: "dog", imageName: "dog2", name: "Brad")
        restaurant11  = Restaurant(food: "dog", imageName:"dog2", name: "Woof")
        
        
        
        
        
        
        persons=[ restaurant1,restaurant3,restaurant4,restaurant5,restaurant6,restaurant7,restaurant4,restaurant8,restaurant9,restaurant10,restaurant11]
        
        
        nearestFirst = Filter(select: false, name: "dog")
        north = Filter(select: false, name: "cat")
        central = Filter(select: false, name: "horse")
        BRB = Filter(select: false, name: "fish")
        west = Filter(select: false, name: "Donate Petcents")
        filters=[nearestFirst,central,north,BRB,west]
        
        
        // TODO: Setup collectionView
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .vertical
        layout.minimumLineSpacing = 40
        layout.minimumInteritemSpacing = padding
        
        
        let layout2 = UICollectionViewFlowLayout()
        layout2.scrollDirection = .horizontal
        
    
      
   
        
        collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collectionView.translatesAutoresizingMaskIntoConstraints = false
        collectionView.backgroundColor = .white
        collectionView.layer.borderColor = UIColor.softgrey.cgColor
        collectionView.register(PersonCollectionViewCell.self, forCellWithReuseIdentifier: personCellReuseIdentifier)
     
        collectionView.dataSource = self
        collectionView.delegate = self
        
        view.addSubview(collectionView)
        
        filterView = UICollectionView(frame: .zero, collectionViewLayout: layout2)
        filterView.translatesAutoresizingMaskIntoConstraints = false
        filterView.backgroundColor = .pastelyellow
        filterView.layer.cornerRadius=30
        filterView.register(FilterCollectionViewCell.self, forCellWithReuseIdentifier: filterCellReuseIdentifier)
        filterView.dataSource = self
        filterView.delegate = self
    
        
        view.addSubview(filterView)
        
       
        
        givedonation=UIButton()
        
        givedonation.backgroundColor = .pastelyellow
        givedonation.addTarget(self, action: #selector(followButtonPressed), for: .touchUpInside)
        givedonation.setTitle("Give Donation", for: .normal)
        givedonation.setTitleColor(.black, for: .normal)
        givedonation.layer.borderColor = UIColor.pastelyellow.cgColor
        givedonation.layer.borderWidth = 1
        givedonation.translatesAutoresizingMaskIntoConstraints = false
        givedonation.contentEdgeInsets = UIEdgeInsets(top: 5, left: 10, bottom: 5, right: 10)
        givedonation.layer.cornerRadius=20
                     view.addSubview(givedonation)
       
       // getdonation=UIButton()
        
        //getdonation.backgroundColor = .softgrey
        //getdonation.addTarget(self, action: #selector(followButtonPressed), for: .touchUpInside)
        //getdonation.setTitle("Get Donation", for: .normal)
        //getdonation.setTitleColor(.white, for: .normal)
        //getdonation.layer.borderColor = UIColor.softgrey.cgColor
        //getdonation.layer.borderWidth = 1
        //getdonation.translatesAutoresizingMaskIntoConstraints = false
        //getdonation.contentEdgeInsets = UIEdgeInsets(top: 5, left: 10, bottom: 5, right: 10)
        //getdonation.layer.cornerRadius=20
                     //view.addSubview(getdonation)
        
        
        
        if selectedFilters == [] {
            restaurants = persons
            collectionView.reloadData()
        }
        
        setupConstraints()
    }

    func setupConstraints() {
        
       
        NSLayoutConstraint.activate([
            givedonation.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: padding),
            givedonation.leadingAnchor.constraint(equalTo: view.leadingAnchor,constant:padding),
            givedonation.bottomAnchor.constraint(equalTo: givedonation.topAnchor,constant:50),
            givedonation.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -padding)
        ])

          //NSLayoutConstraint.activate([
           // getdonation.topAnchor.constraint(equalTo: givedonation.bottomAnchor, constant: padding),
            //  getdonation.leadingAnchor.constraint(equalTo: view.leadingAnchor,constant:padding),
             // getdonation.bottomAnchor.constraint(equalTo: getdonation.topAnchor,constant:50),
              //getdonation.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -padding)
          //])
          
        
        
      
        
        NSLayoutConstraint.activate([
            filterView.topAnchor.constraint(equalTo: givedonation.bottomAnchor, constant: padding),
            filterView.leadingAnchor.constraint(equalTo: view.leadingAnchor,constant:padding),
            filterView.bottomAnchor.constraint(equalTo: givedonation.bottomAnchor,constant:75),
            filterView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -padding)
        ])
        
        NSLayoutConstraint.activate([
            collectionView.topAnchor.constraint(equalTo: filterView.bottomAnchor, constant: padding),
            collectionView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: padding),
            collectionView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            collectionView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -padding)
        ])
    }

}

extension ViewController: UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if(collectionView == self.collectionView)
        {
            return restaurants.count}
        else
        {return filters.count}
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
       
                         
        if(collectionView==self.collectionView){
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: personCellReuseIdentifier, for: indexPath) as! PersonCollectionViewCell
        cell.configure(for: restaurants[indexPath.row])
            
            
            return cell
            
        }
        else{
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: filterCellReuseIdentifier, for: indexPath) as! FilterCollectionViewCell
            cell.configure(for: filters[indexPath.row])
            
            
            return cell
        }
    }
    
   

}

extension ViewController: UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        // We want: | padding CELL padding CELL padding CELL padding |
        if(collectionView==self.collectionView){
        let size = (collectionView.frame.width -  padding) / 1.0
            return CGSize(width: size, height: size/1.5)}
        else{
            let size = (collectionView.frame.width - 2*padding) / 3.0
                     return CGSize(width: size, height: 30)
        }
    }
    
    
}

extension ViewController: UICollectionViewDelegate {
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if(collectionView==self.filterView)
        {
            let cell = self.filterView.cellForItem(at: indexPath) as! FilterCollectionViewCell
            
            
            
            cell.followButtonPressed()
           // print(indexPath)
            if cell.isFollowing {
                selectedFilters.append(cell.filterName)
            } else {
                var removeIndex: Int!
                
                for filter in selectedFilters {
                    if filter == cell.filterName {
                        removeIndex = selectedFilters.firstIndex(of: filter)
                    }
                }

                selectedFilters.remove(at: removeIndex)
            }
            
            
            restaurants = []
            
            for selectedFilter in selectedFilters {
                
                for i in persons
                {
                    
                    if(i.food==selectedFilter)
                    {
                        // Check that resturants doesnt contain the new one (No duplicates)
                        restaurants.append(i)

                    }
                    
                }
            }
            // Handle the case of not following (removing restuarants with this filter
            
            self.collectionView.reloadData()
             //for i in persons
            // {
               // if(i.food==filters[indexPath.row].name)
               // {
                 // i.selected.toggle()
               // }
                
                //collectionView.reloadData()
               
        }
            
            if selectedFilters == [] {
                restaurants = persons
                collectionView.reloadData()
            }
            
            
        
            
 if collectionView == self.collectionView {
        var newvc = searchView()
        print(indexPath.row)
    
        //print(restaurants[indexPath.row])
       newvc.restaurant = restaurants[indexPath.row]
        navigationController?.pushViewController(newvc, animated: true)
        
        collectionView.reloadData()
        }
        
      
        
        
        }
    
    @objc func followButtonPressed() {
           
                 givedonation.setTitleColor(isselected ? .white : .red, for: .normal)
                 givedonation.backgroundColor = isselected ? .red : .white
               isselected.toggle()
               var  vc = ViewController2()
               
                   
                   navigationController?.pushViewController(vc, animated: true)
                   
                   
                 
             
       }
    

        
        
        
      
        
}
extension UIColor {

  @nonobjc class var softBlue: UIColor {
    return UIColor(red: 87.0 / 255.0, green: 130.0 / 255.0, blue: 247.0 / 255.0, alpha: 1.0)
  }

  @nonobjc class var white: UIColor {
    return UIColor(white: 1.0, alpha: 1.0)
  }
    
    @nonobjc class var pastelyellow: UIColor {
        return UIColor(red: 255.0 / 255.0, green: 241.0 / 255.0, blue: 173.0 / 255.0, alpha: 1.0)
    }

    
    @nonobjc class var softgrey: UIColor {
        return UIColor(red: 87.0 / 255.0, green: 78.0 / 255.0, blue: 42.0 / 255.0, alpha: 1.0)
    }


}


